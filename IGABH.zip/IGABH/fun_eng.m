%% Engineering Benchmark functions

function[lowerbound,upperbound,dimension,fitness] = fun_eng(F)

% Parameters of the various Engineering Benchmarks

switch F
 %Define the properties of COP (tension/compression spring design problem)
    case 'F1'
        fitness = @F1;
        lowerbound=[0.05 0.25 2];
        upperbound=[2 1.3 15];
        dimension=3;

% Haverly 
case 'F2'
        fitness = @F2;
        lowerbound=[0 0 0 0 0 0 0 0 0];
        upperbound=[100 100 100 100 100 100 1 1 1];
        dimension=9;

% Speed Reducer
case 'F3'
        fitness = @F3;
        lowerbound = [2.6, 0.7, 17, 7.3, 7.3, 2.9, 5];
        upperbound = [3.6, 0.8, 28, 8.3, 8.3, 3.9, 5.5];
        dimension=7;

% Pressure vessel design
case 'F4'
        fitness = @F4;
        lowerbound = [0.51,0.51,10,10];
        upperbound = [99.49,99.49,200,200];
        dimension=4;

% Hydrostatic 

% Three-bar truss design problem
case 'F5'
        fitness = @F5;
        lowerbound = 0*ones(1,2);
        upperbound = 1*ones(1,2);
        dimension=2;

% Design of gear train
case 'F6'
        fitness = @F6;
        lowerbound = 12*ones(1,4);
        upperbound = 60*ones(1,4);
        dimension=4;

 % Cantilever beam
 case 'F7'
        fitness = @F7;
        lowerbound = [0.01 0.01 0.01 0.01 0.01];
        upperbound = [100 100 100 100 100];
        dimension=5;

% Tubular column design
case 'F8'
        fitness = @F8;
        lowerbound = [2 0.2];
        upperbound = [14 0.8];
        dimension=2;

% Design of welded beam design
case 'F9'
        fitness = @F9;
        lowerbound = [0.1 0.1 0.1 0.1];
        upperbound = [2 10 10 2];
        dimension=4;

% Robot Gripper 
% case 'F10'
%         fitness = @F10;
%         lowerbound = [10 10 100 0 10 100 1];
%         upperbound = [150 150 200 50 150 300 3.14];
%         dimension=7;
end
end

%% Constrained Optimization Problem Definitions

% The Tension/Compression Spring Design Problem
 function R=F1(X) 
% % Calculate inequality constraints (g(i)). Number of inequality constraints(l) is 4.
g(1)=1-(X(2)^3*X(3))/(71785*X(1)^4);
g(2)=(4*X(2)^2-X(1)*X(2))/(12566*(X(2)*X(1)^3-X(1)^4))+1/(5108*X(1)^2)-1;
g(3)=1-(140.45*X(1))/(X(2)^2*X(3));
g(4)=(X(1)+X(2))/(1.5)-1;

% % Calculate the cost function (fit)of the Tension/Compression Spring Design.
 fit=(X(3)+2)*X(2)*X(1)^2;
 
% % Defining the penalty parameter (represented here with nou). Notice that
% % penalty parameter is considered as a very big number and equal for all four
% % inequality constraints.
 penalty_factor = [3 4 0.1 0.1]; %Original Penalty factor for code
%penalty_factor = [10 10 10 10]; %penalty factor for IGABH manuscript
penalty=0;
for i=1:size(g,2)
if g(i)>0
%penalty = penalty + penalty_factor(i)*g(i); %Original    
penalty = penalty + penalty_factor(i)*(g(i)).^2; %for IGABH manuscript
end
end 
% % Calculate the penalized cost function (pfit) by adding measure of penalty function (penalty).
R=fit+penalty;
end

%Objective and constraint function for Haverly's Pooling Problem
function R = F2(X)
    %  Haverly's Pooling Objective function
    fit = -(9 * X(1) + 15 * X(2) - 6 * X(3) - 16 * X(4) - 10 * (X(5) + X(6)));

    % Constraints for Haverly's Pooling Problem
    g(1) = X(9) * X(7) + 2 * X(5) - 2.5 * X(1);
    g(2) = X(9) * X(8) + 2 * X(6) - 1.5 * X(2);
    h(1) = X(7) + X(8) - X(3) - X(4);
    h(2) = X(1) - X(7) - X(5);
    h(3) = X(2) - X(8) - X(6);
    h(4) = X(9) * X(7) + X(9) * X(8) - 3 * X(3) - X(4);

    % Penalty for constraint violations
    penalty = 0;
    nu = 10^9; % Large penalty factor
    penalty_factor = [1e6, 1e6, 1e9, 1e9, 1e8, 1e8];
    for i = 1:length(g)
        if g(i) > 0
            penalty = penalty + penalty_factor(i) * g(i);
        end
    end
    for j = 1:length(h)
        penalty = penalty + nu * abs(h(j));
    end

    % Penalized fitness
    R = fit + penalty;
end 

% Objective and constraint function for Speed Reducer Design Optimization Problem
function R = F3(X)

    % Objective function (Weight Minimization)
    fit = 0.7854 * X(:,1) .* X(:,2).^2 .* (3.3333 * X(:,3).^2 + 14.9334 * X(:,3) - 43.0934) - ...
          1.508 * X(:,1) .* (X(:,6).^2 + X(:,7).^2) + 7.477 * (X(:,6).^3 + X(:,7).^3) + ...
          0.7854 * (X(:,4) .* X(:,6).^2 + X(:,5) .* X(:,7).^2);

    % Constraints
    g(:,1) = 27 - (X(:,1) .* X(:,2).^2 .* X(:,3));
    g(:,2) = 397.5 - (X(:,1) .* X(:,2).^2 .* X(:,3).^2);
    g(:,3) = 1.93 - (X(:,2) .* X(:,6).^4 .* X(:,3) ./ X(:,4).^3);
    g(:,4) = 1.93 - (X(:,2) .* X(:,7).^4 .* X(:,3) ./ X(:,5).^3);
    g(:,5) = 1100 - 10 * X(:,6).^(-3) .* sqrt(16.91 * 10^6 + (745 * X(:,4) ./ (X(:,2) .* X(:,3))).^2);
    g(:,6) = 850 - 10 * X(:,7).^(-3) .* sqrt(157.5 * 10^6 + (745 * X(:,5) ./ (X(:,2) .* X(:,3))).^2);
    g(:,7) = X(:,2) .* X(:,3) - 40;
    g(:,8) = 5 - X(:,1) ./ X(:,2);
    g(:,9) = X(:,1) ./ X(:,2) - 12;
    g(:,10) = 1.5 * X(:,6) - X(:,4) + 1.9;
    g(:,11) = 1.1 * X(:,7) - X(:,5) + 1.9;

    % Penalty for constraint violations
    penalty = 0;
    penalty_factor = [50 10 1 1 1 20 1 300 1 1 50 1];
 % Large penalty factor
    for i = 1:size(g, 2)
        penalty = penalty + penalty_factor(i) * max(0, g(:,i));
    end

    % Penalized fitness
   R = fit + penalty;
end

% Pressure Vessel Design
function R = F4(X)
   % Round variables to nearest increments of 0.0625
    X(:,1) = 0.0625 * round(X(:,1));
    X(:,2) = 0.0625 * round(X(:,2));
    
    % Objective function
    fit = 0.6224 * X(:,1) .* X(:,3) .* X(:,4) + 1.7781 * X(:,2) .* X(:,3).^2 + ...
          3.1661 * X(:,1).^2 .* X(:,4) + 19.84 * X(:,1).^2 .* X(:,3);

    % Constraints
    g(:,1) = 0.0193 * X(:,3) - X(:,1);
    g(:,2) = 0.00954 * X(:,3) - X(:,2);
    g(:,3) = 1296000 - pi * X(:,3).^2 .* X(:,4) - (4/3) * pi * X(:,3).^3;
    g(:,4) = X(:,4) - 240;

    % Penalty for constraint violations
    penalty = 0;
   penalty_factor = [12000 8000 1 1 1]; % Large penalty vector

    for i = 1:size(g, 2)
        penalty = penalty + penalty_factor(i)* max(0, g(:,i));
    end

    % Penalized fitness
    R = fit + penalty;
end

%  % Objective and constraint function for Hydrostatic Thrust Bearing Design Optimization Problem
% function [fit, pfit] = fobj(X, Lb, Ub)
%     % Variable assignment
%     R = X(:,1); Ro = X(:,2); mu = X(:,3); Q = X(:,4);
%     gamma = 0.0307; C = 0.5; n = -3.55; C1 = 10.04;
%     Ws = 101000; Pmax = 1000; delTmax = 50; hmin = 0.001;
%     gg = 386.4; N = 750;
% 
%     % Objective function
%     P = (log10(log10(8.122 * 1e6 .* mu + 0.8)) - C1) ./ n;
%     delT = 2 * (10.^P - 560);
%     Ef = 9336 * Q .* gamma .* C .* delT;
%     h = (2 * pi * N / 60)^2 * 2 * pi * mu / Ef * (R.^4 / 4 - Ro.^4 / 4) - 1e-5;
%     Po = (6 * mu .* Q ./ (pi .* h.^3)) .* log(R ./ Ro);
%     W = pi * Po / 2 .* (R.^2 - Ro.^2) ./ (log(R ./ Ro) - 1e-5);
%     fit = (Q .* Po / 0.7 + Ef) / 12;
% 
%     % Constraints
%     g(:,1) = Ws - W;
%     g(:,2) = Po - Pmax;
%     g(:,3) = delT - delTmax;
%     g(:,4) = hmin - h;
%     g(:,5) = Ro - R;
%     g(:,6) = gamma / (gg * Po) * (Q / (2 * pi * R .* h)) - 0.001;
%     g(:,7) = W / (pi * (R.^2 - Ro.^2) + 1e-5) - 5000;
% 
%     % Penalty for constraint violations
%     penalty = 0;
%     nu = 10^9; % Large penalty factor
%     for i = 1:size(g, 2)
%         penalty = penalty + nu * max(0, g(:,i));
%     end
% 
%     % Penalized fitness
%     pfit = fit + penalty;
% end

% Objective and constraint function for Three-Bar Truss Design Optimization Problem
function R = F5(X)
    % Objective function
    fit = (2 * sqrt(2) * X(:,1) + X(:,2)) * 100;

    % Constraints
    g(:,1) = (sqrt(2) * X(:,1) + X(:,2)) / (sqrt(2) * X(:,1).^2 + 2 * X(:,1) .* X(:,2)) * 2 - 2;
    g(:,2) = X(:,2) / (sqrt(2) * X(:,1).^2 + 2 * X(:,1) .* X(:,2)) * 2 - 2;
    g(:,3) = 1 / (sqrt(2) * X(:,2) + X(:,1)) * 2 - 2;

    % Penalty for constraint violations
    penalty = 0;
    penalty_factor = [140 7 15 1];

    % nu = 10^9; % Large penalty factor
    for i = 1:size(g, 2)
        penalty = penalty + penalty_factor(i) * max(0, g(:,i));
    end

    % Penalized fitness
    R = fit + penalty;
end

% Gear Train Design
function R = F6(X)
    % Round variables to integers
    X = round(X);

    % Objective function
    term1 = 1 / 6.931;
    term2 = (X(:,3) .* X(:,2)) ./ (X(:,1) .* X(:,4));
    fit = (term1 - term2).^2;

    % Constraints
    g = 0; % No inequality constraints
    h = 0; % No equality constraints

    % Penalized fitness is the same as fit since there are no constraints
    R = fit;
end

% Objective and constraint function for Reactor Network Design Optimization Problem
% function [fit, pfit] = fobj(X, Lb, Ub)
%     % Constants
%     k1 = 0.09755988;
%     k2 = 0.99 * k1;
%     k3 = 0.0391908;
%     k4 = 0.9 * k3;
% 
%     % Objective function
%     fit = -X(:,4);
% 
%     % Equality constraints
%     h(:,1) = X(:,1) + k1 * X(:,2) .* X(:,5) - 1;
%     h(:,2) = X(:,2) - X(:,1) + k2 * X(:,2) .* X(:,6);
%     h(:,3) = X(:,3) + X(:,1) + k3 * X(:,3) .* X(:,5) - 1;
%     h(:,4) = X(:,4) - X(:,3) + X(:,2) - X(:,1) + k4 * X(:,4) .* X(:,6);
%     
%     % Inequality constraint
%     g(:,1) = sqrt(X(:,5)) + sqrt(X(:,6)) - 4;
% 
%     % Penalty for constraint violations
%     penalty = 0;
%     nu = 10^9; % Large penalty factor
%     for i = 1:size(h, 2)
%         penalty = penalty + nu * abs(h(:,i));
%     end
%     for i = 1:size(g, 2)
%         penalty = penalty + nu * max(0, g(:,i));
%     end
% 
%     % Penalized fitness
%     pfit = fit + penalty;
% end

% Objective and constraint function for Tubular Column Design Optimization Problem
 function R = F8(X)
    % Objective function
    fit = 9.8 * X(:,1) .* X(:,2) + 2 * X(:,1);

    % Constraints
    g(:,1) = 1.59 - X(:,1) .* X(:,2);
    g(:,2) = 47.4 - X(:,1) .* X(:,2) .* (X(:,1).^2 + X(:,2).^2);
    g(:,3) = 2 / X(:,1) - 1;
    g(:,4) = X(:,1) / 14 - 1;
    g(:,5) = 2 / X(:,1) - 1;
    g(:,6) = X(:,1) / 8 - 1;

    % Penalty for constraint violations
    penalty = 0;
    penalty_factor = [100 1 1 1 1 1 1];
%     nu = 10^9; % Large penalty factor
    for i = 1:size(g, 2)
        penalty = penalty + penalty_factor(i) * max(0, g(:,i));
    end

    % Penalized fitness
   R = fit + penalty;
end

% Objective and constraint function for Cantilever Beam Design Optimization Problem
function R = F7(X)
    % Objective function
    fit = 0.0624 * (X(:,1) + X(:,2) + X(:,3) + X(:,4) + X(:,5));

    % Constraint
    g(:,1) = (61 ./ X(:,1).^3) + (37 ./ X(:,2).^3) + (19 ./ X(:,3).^3) + (7 ./ X(:,4).^3) + (1 ./ X(:,5).^3) - 1;

    % Penalty for constraint violations
    penalty = 0;
    penalty_factor = [10 1];

    % nu = 10^9; % Large penalty factor
    for i = 1:size(g, 2)
        penalty = penalty + penalty_factor(i)* max(0, g(:,i));
    end

    % Penalized fitness
   R = fit + penalty;
end

% Objective and constraint function for Welded Beam Design Optimization Problem
function R = F9(X)
    % Constants
    p = 6000;
    l = 14;
    e = 30e6;
    g = 12e6;
    deltamax = 0.25;
    tomax = 13600;
    sigmamax = 30000;
    m = p * (l + X(:,2) / 2);
    r = sqrt((X(:,2) / 2)^2 + ((X(:,1) + X(:,3)) / 2)^2);
    j = 2 * sqrt(2) * X(:,1) .* X(:,2) .* (X(:,2).^2 / 12 + ((X(:,1) + X(:,3)) / 2).^2);
 
    % Objective function
    fit = 1.1047 * X(:,1).^2 .* X(:,2) + 0.04811 * X(:,3) .* X(:,4) .* (14 + X(:,2));

    % Constraints
    toprim = p / (sqrt(2) * X(:,1) .* X(:,2));
    tozegond = m * r / j;
    sigma = 6 * p * l / (X(:,4) .* X(:,3).^2);
    delta = (4 * p * l^3) / (e * X(:,3).^3 .* X(:,4));
    pc = (4.013 *e * sqrt((X(:,3).^2 * X(:,4).^6 / 36)) / l^2) * (1 - 0.5 * (X(:,3) / l) * sqrt(e / (4 * g)));
    to = sqrt(toprim.^2 + 2 * toprim .* tozegond .* X(:,2) / (2 * r) + tozegond.^2);
    
    g(:,1) = to - tomax;
    g(:,2) = sigma - sigmamax;
    g(:,3) = X(:,1) - X(:,4);
    g(:,4) = 0.10471 * X(:,1).^2 + 0.04811 * X(:,3) .* X(:,4) .* (14 + X(:,2)) - 5;
    g(:,5) = 0.125 - X(:,1);
    g(:,6) = delta - deltamax;
    g(:,7) = p - pc;
 
    % Penalty for constraint violations
    penalty = 0;
    penalty_factor = [1 1 4 0.001 1 0.5 1]; %Original Penalty factor for code
   % penalty_factor = [10 10 10 10 10 10 10 ]; % Penalty factor for IGABH manuscript
    % nu = 10^9; % Large penalty factor
    for i = 1:size(g, 2)
       % penalty = penalty + penalty_factor(i) * max(0, g(:,i)); %Original
        penalty = penalty + penalty_factor(i)*max(0, g(:,i)).^2; %for IGABH manuscript
    end

    % Penalized fitness
   R = fit + penalty;
end

% Objective and constraint function for Robot Gripper Design Optimization Problem
% function [fit, pfit] = fobj(X, Lb, Ub)
% 
% % Objective function for OBJ11
% function [fit, pfit] = OBJ11(X, n)
%     % Variable definitions
%     a = X(:,1); 
%     b = X(:,2); 
%     c = X(:,3); 
%     e = X(:,4); 
%     f = X(:,5); 
%     l = X(:,6); 
%     Zmax = 99.9999; 
%     P = 100;
% 
%     % Define the function handle for fhd based on n
%     if n == 1
%         fhd = @(z) P .* b .* sin(acos((a.^2 + (l - z).^2 + e.^2 - b.^2) ./ (2 .* a .* sqrt((l - z).^2 + e.^2))) + ...
%                       acos((b.^2 + (l - z).^2 + e.^2 - a.^2) ./ (2 .* b .* sqrt((l - z).^2 + e.^2)))) ./ ...
%                       (2 .* c .* cos(acos((a.^2 + (l - z).^2 + e.^2 - b.^2) ./ (2 .* a .* sqrt((l - z).^2 + e.^2))) + ...
%                       atan(e ./ (l - z))));
%     else
%         fhd = @(z) -(P .* b .* sin(acos((a.^2 + (l - z).^2 + e.^2 - b.^2) ./ (2 .* a .* sqrt((l - z).^2 + e.^2))) + ...
%                        acos((b.^2 + (l - z).^2 + e.^2 - a.^2) ./ (2 .* b .* sqrt((l - z).^2 + e.^2)))) ./ ...
%                        (2 .* c .* cos(acos((a.^2 + (l - z).^2 + e.^2 - b.^2) ./ (2 .* a .* sqrt((l - z).^2 + e.^2))) + ...
%                        atan(e ./ (l - z)))));
%     end
% 
%     % Optimize with fminbnd to find minimum value of fhd over the interval [0, Zmax]
%     options = optimset('Display', 'off');
%     [~, fit] = fminbnd(fhd, 0, Zmax, options);
% 
%     % Penalized fitness (since no constraints are specified, fit and pfit are identical)
%     pfit = fit;
% end
% 
%     % Variable assignment
%     a = X(:,1); b = X(:,2); c = X(:,3); e = X(:,4); ff = X(:,5); l = X(:,6); delta = X(:,7);
%     Ymin = 50; Ymax = 100; YG = 150; Zmax = 99.9999; P = 100;
%     
%     % Calculations for objective
%     alpha_0 = acos((a.^2 + l.^2 + e.^2 - b.^2) ./ (2 * a .* sqrt(l.^2 + e.^2))) + atan(e ./ l);
%     beta_0  = acos((b.^2 + l.^2 + e.^2 - a.^2) ./ (2 * b .* sqrt(l.^2 + e.^2))) - atan(e ./ l);
%     alpha_m = acos((a.^2 + (l - Zmax).^2 + e.^2 - b.^2) ./ (2 * a .* sqrt((l - Zmax).^2 + e.^2))) + atan(e ./ (l - Zmax));
%     beta_m  = acos((b.^2 + (l - Zmax).^2 + e.^2 - a.^2) ./ (2 * b .* sqrt((l - Zmax).^2 + e.^2))) - atan(e ./ (l - Zmax));
%     
%     % Objective function
%     fit = -OBJ11(X, 2) - OBJ11(X, 1);
% 
%     % Constraints
%     Yxmin = 2 * (e + ff + c .* sin(beta_m + delta));
%     Yxmax = 2 * (e + ff + c .* sin(beta_0 + delta));
%     g(:,1) = Yxmin - Ymin;
%     g(:,2) = -Yxmin;
%     g(:,3) = Ymax - Yxmax;
%     g(:,4) = Yxmax - YG;
%     g(:,5) = l.^2 + e.^2 - (a + b).^2;
%     g(:,6) = b.^2 - (a - e).^2 - (l - Zmax).^2;
%     g(:,7) = Zmax - l;
% 
%     % Penalty for constraint violations
%     penalty = 0;
%     nu = 10^9; % Large penalty factor
%     for i = 1:size(g, 2)
%         penalty = penalty + nu * max(0, g(:,i));
%     end
% 
%     % Penalized fitness
%     pfit = fit + penalty;
% end


