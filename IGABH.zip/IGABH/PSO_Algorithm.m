% Copyright (c) 2015, Yarpiz (www.yarpiz.com)
% All rights reserved. Please read the "license.txt" for license terms.
%
% Project Code: YPEA102
% Project Title: Implementation of Particle Swarm Optimization in MATLAB
% Publisher: Yarpiz (www.yarpiz.com)
% 
% Developer: S. Mostapha Kalami Heris (Member of Yarpiz Team)
% 
% Contact Info: sm.kalami@gmail.com, info@yarpiz.com

clc;
clear;
close all;

z=0;
runs= 30;
optimalruns=zeros(runs,1);
runtime_data = zeros(runs,1);  % Array to store runtime for each run

% Create timing statistics Excel file with headers first
timing_filename = 'PSO_Algorithm_Benchmark_Timing_Statistics.xlsx';

% Create header row for summary sheet at the beginning
summary_header = table(...
    {'Function'}, ...
    {'Average_Runtime'}, ...
    {'Min_Runtime'}, ...
    {'Max_Runtime'}, ...
    {'Std_Runtime'}, ...
    {'Total_Runtime'}, ...
    'VariableNames', {'Function', 'Average_Runtime', 'Min_Runtime', 'Max_Runtime', 'Std_Runtime', 'Total_Runtime'});

writetable(summary_header, timing_filename, 'Sheet', 'Summary', 'Range', 'A1');

  
for uu=1:23 %loop for Engineering problems or benchmark functions i.e. max(uu)=10 for engineering problems    
    
%Reset z for each new benchmark function (F2,F3,...,Fn) run
if uu>1
    z=0;
end
    
Letter = char('F'); %Basically assigning letter F to 'Letter'   
range = [Letter num2str(uu)]; %forming the fun name i.e F1, F2, F3 etc, the loop for the functions determines th value of u
Fun_name = range; 

%%Use this code when testing PSO on the set of 23 standard CEC benchmarks
[lb,ub,D,out] = fun_info(Fun_name);
lowerbound = lb;
upperbound = ub;
dimension = D;
fitness = out;

% %%Use this code when testing PSO on the 10 Engineering benchmarks
% [lb,ub,D,out] = fun_eng(Fun_name);
% lowerbound = lb;
% upperbound = ub;
% dimension = D;
% fitness = out;

for io=1:runs  %loop for number of runs
 % Start timing for this run
        tic;
        
ObjectiveFunction=fitness;
nVar=dimension;
varMin=lowerbound;
varMax=upperbound;

%% Problem Definition
VarSize=[1 nVar];   % Size of Decision Variables Matrix

%% PSO Parameters
MaxIt=2000;      % Maximum Number of Iterations
nPop=50;        % Population Size (Swarm Size)
w=1;            % Inertia Weight
wdamp=0.99;     % Inertia Weight Damping Ratio
c1=1.5;         % Personal Learning Coefficient
c2=2.0;         % Global Learning Coefficient

% If you would like to use Constriction Coefficients for PSO,
% uncomment the following block and comment the above set of parameters.

% % Constriction Coefficients (PSO parameters)
% phi1=2.05;
% phi2=2.05;
% phi=phi1+phi2;
% chi=2/(phi-2+sqrt(phi^2-4*phi));
% w=chi;          % Inertia Weight
% wdamp=1;        % Inertia Weight Damping Ratio
% c1=chi*phi1;    % Personal Learning Coefficient
% c2=chi*phi2;    % Global Learning Coefficient

% Velocity Limits
VelMax=0.1*(varMax-varMin);
VelMin=-VelMax;

%% Initialization
empty_particle.Position=[];
empty_particle.Cost=[];
empty_particle.Velocity=[];
empty_particle.Best.Position=[];
empty_particle.Best.Cost=[];

particle=repmat(empty_particle,nPop,1);

GlobalBest.Cost=inf;

for i=1:nPop
    
    % Initialize Position
    particle(i).Position=unifrnd(varMin,varMax,VarSize);
    
    % Initialize Velocity
    particle(i).Velocity=zeros(VarSize);
    
    % Evaluation
    particle(i).Cost=ObjectiveFunction(particle(i).Position);
    
    % Update Personal Best
    particle(i).Best.Position=particle(i).Position;
    particle(i).Best.Cost=particle(i).Cost;
    
    % Update Global Best
    if particle(i).Best.Cost<GlobalBest.Cost
        
        GlobalBest=particle(i).Best;
        
    end
    
end

BestCost=zeros(MaxIt,1);

%% PSO Main Loop

for it=1:MaxIt
    
    for i=1:nPop
        
        % Update Velocity
        particle(i).Velocity = w*particle(i).Velocity ...
            +c1*rand(VarSize).*(particle(i).Best.Position-particle(i).Position) ...
            +c2*rand(VarSize).*(GlobalBest.Position-particle(i).Position);
        
        % Apply Velocity Limits
        particle(i).Velocity = max(particle(i).Velocity,VelMin);
        particle(i).Velocity = min(particle(i).Velocity,VelMax);
        
        % Update Position
        particle(i).Position = particle(i).Position + particle(i).Velocity;
        
        % Velocity Mirror Effect
        IsOutside=(particle(i).Position<varMin | particle(i).Position>varMax);
        particle(i).Velocity(IsOutside)=-particle(i).Velocity(IsOutside);
        
        % Apply Position Limits
        particle(i).Position = max(particle(i).Position,varMin);
        particle(i).Position = min(particle(i).Position,varMax);
        
        % Evaluation
        particle(i).Cost = ObjectiveFunction(particle(i).Position);
        
        % Update Personal Best
        if particle(i).Cost<particle(i).Best.Cost
            
            particle(i).Best.Position=particle(i).Position;
            particle(i).Best.Cost=particle(i).Cost;
            
            % Update Global Best
            if particle(i).Best.Cost<GlobalBest.Cost
                
                GlobalBest=particle(i).Best;
                
            end
            
        end
        
    end
    
    BestCost(it)=GlobalBest.Cost;
    
    disp(['Iteration ' num2str(it) ': Best Cost = ' num2str(BestCost(it))]);
    
    w=w*wdamp;
    
BestSol = GlobalBest;
    
end
% End timing for this run
    runtime_data(io) = toc;
    
 %BestCost for n number of runs
    optimalruns(io)=min(BestCost);
    
 %%% Exporting optimum values to excel %%%%
Algorithm = {'PSO_Algorithm'};
Minvalt = min(BestCost); %%% Assigning the optimum value of each algorithm to minvalt
Comparison = table(Minvalt, 'VariableNames', {'Minvalt'}); %%% changing into a table form
filename = 'PSO_Algorithm_Benchmarks_Optimal_Values.xlsx';   %%% Creating excel file

if io<27  %%% for the first 26 runs, this is to store the values in excel column cells A to z
    Letter=char('A'+ z);
    range=[Letter '2'];
    
else  %%% for runs 27 to 50, this is to store the values in excel column cells AA to AX
    Letter=char('A'+ z);
    range1 = ['A' Letter];
    range=[range1 '2'];
end

z=z+1;
if io==26
    z=0;
end

writetable(Comparison,filename,'Sheet', uu,'Range',range) %%%writing into the the excel file

end

% Calculate timing statistics for current function
    avg_runtime = mean(runtime_data);
    min_runtime = min(runtime_data);
    max_runtime = max(runtime_data);
    std_runtime = std(runtime_data);
       
    % Create timing statistics table
    timing_stats = table(...
        {Fun_name}, ...
        avg_runtime, ...
        min_runtime, ...
        max_runtime, ...
        std_runtime, ...
        sum(runtime_data), ...
 'VariableNames', {'Function', 'Average_Runtime', 'Min_Runtime', 'Max_Runtime', 'Std_Runtime', 'Total_Runtime'});
    
    % Write timing statistics to Excel
 writetable(timing_stats, timing_filename, 'Sheet', 'Summary', 'Range', ['A' num2str(uu+1)], 'WriteVariableNames', false );
    
    % Export individual run times to Excel
    run_numbers = (1:runs)';
    individual_runtimes = table(run_numbers, runtime_data, 'VariableNames', {'Run_Number', 'Runtime_Seconds'});
    writetable(individual_runtimes, timing_filename, 'Sheet', Fun_name, 'Range', 'A1');
       
% Calculate and display overall statistics
bestfitnessruns=min(optimalruns);
Mean=mean(optimalruns);
Standarddeviation= std(optimalruns);
bestfitnessruns
Mean
Standarddeviation

% %Exporting Convergence Curve values for each func (F1-F23) to excel sheet
filename1 = 'PSO_Algorithm_Benchmarks_convergencecurves.xlsx';
Algorithm1 = {'PSO_Algorithm'};
PSO_conv = [BestCost'];
Comparison1=table( PSO_conv);
writetable(Comparison1,filename1,'Sheet', uu,'Range','B2')

end
