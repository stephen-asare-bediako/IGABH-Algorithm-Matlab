clc;
close all
clearvars

z=0;
runs= 30;
optimalruns=zeros(runs,1);
runtime_data = zeros(runs,1);  % Array to store runtime for each run

% Create timing statistics Excel file with headers first
timing_filename = 'Genetic_Algorithm_Timing_Statistics.xlsx';

% Create header row for summary sheet at the beginning
summary_header = table(...
    {'Function'}, ...
    {'Average_Runtime'}, ...
    {'Min_Runtime'}, ...
    {'Max_Runtime'}, ...
    {'Std_Runtime'}, ...
    {'Total_Runtime'}, ...
    'VariableNames', {'Function', 'Average_Runtime', 'Min_Runtime', 'Max_Runtime', 'Std_Runtime', 'Total_Runtime'});

writetable(summary_header, timing_filename, 'Sheet', 'Summary', 'Range', 'A1');

  
for uu=1:23   %loop for Engineering problems or benchmark functions i.e. NB: max(uu)= 10 for engineering    
    
   clear bestcost 
    
%Reset z for each new benchmark function (F2,F3,...,Fn) run
if uu>1
    z=0;
end
    
Letter = char('F'); %Basically assigning letter F to 'Letter'   
range = [Letter num2str(uu)]; %forming the fun name i.e F1, F2, F3 etc, the loop for the functions determines th value of u
Fun_name = range; 

%%Use this code when testing Genetic Algorithm on the set of 23 standard CEC benchmarks
[lb,ub,D,out] = fun_info(Fun_name);
lowerbound = lb;
upperbound = ub;
dimension = D;
fitness = out;

% %%Use this code when testing Genetic Algorithm on the 10 Engineering benchmarks
% [lb,ub,D,out] = fun_eng(Fun_name);
% lowerbound = lb;
% upperbound = ub;
% dimension = D;
% fitness = out;

for io=1:runs  %loop for number of runs
 % Start timing for this run
        tic;
        
ObjectiveFunction=fitness;
nVar=dimension;
varMin=lowerbound;
varMax=upperbound;

%Genetic Algorithm Parameters
MaxIter=2000; 
nPop=50;
%% Problem Definition
problem.CostFunction = ObjectiveFunction;
problem.nVar = nVar;
problem.varMin = varMin;
problem.varMax = varMax;

%% GA Parameters
params.MaxIt = MaxIter;
params.nPop = nPop;
params.beta = 1;
params.pC = 1;
params.gamma = 0.1;
params.mu = 0.02;
params.sigma = 0.1;
% Params
MaxIt = params.MaxIt;
nPop = params.nPop;
beta = params.beta;
pC = params.pC;
nC = round(pC*nPop/2)*2;
gamma = params.gamma;
mu = params.mu;
sigma = params.sigma;

%% Run GA
% Template for Empty individuals
    empty_individual.Position = [];
    empty_individual.Objective = [];

    % Best Solution Ever Found
    bestsol.Position = [];
    bestsol.Objective = inf;
 
    % Population Initialization
    pop = repmat(empty_individual, nPop, 1);
    for i = 1:nPop

        % Generate Random Solution
        pop(i).Position = unifrnd(varMin, varMax, [1, nVar]);

        % Evaluate Solution
        pop(i).Objective = ObjectiveFunction(pop(i).Position);

        % Compare Solution to Best Solution Ever Found
        if pop(i).Objective < bestsol.Objective
            bestsol.Position = pop(i).Position;
            bestsol.Objective = pop(i).Objective;
        end

    end

    % Best Solutions of iterations
    bestObjective = nan(MaxIt, 1);

    % Main Loop
    for it = 1:MaxIt

        % Selection Probabilities
        c = [pop.Objective];
        avgc = mean(c);
        if avgc ~= 0
            c = c / avgc;
        end

        probs = exp(-beta * c);

        % Initialize Offsprings Population
        popc = repmat(empty_individual, nC / 2, 2);

        % Crossover
        for k = 1:nC / 2

            % Select Parents
            p1 = pop(RouletteWheelSelection(probs));
            p2 = pop(RouletteWheelSelection(probs));

            % Perform Crossover
            [popc(k, 1).Position, popc(k, 2).Position] = ...
                UniformCrossover(p1.Position, p2.Position);
            
        end
      
  % Convert popc to Single Column Matrix
        popc = popc(:);
        
%Imposing varMin & varMax limits so that battery size will always
%be within the limits
         for i=1:numel(popc)    
        popc(i).Position = max(popc(i).Position, varMin);
        popc(i).Position = min(popc(i).Position, varMax);
         end
         
        % Mutation
        for l = 1:nC
            % Perform Mutation
            popc(l).Position = Mutate(popc(l).Position, mu, sigma);
            
     %Imposing varMin & varMax limits so that battery size will always
    %be within the limits
               for ll = 1:numel(popc)
          popc(ll).Position = max(popc(ll).Position, varMin);
          popc(ll).Position = min(popc(ll).Position, varMax);
               end
            % Evaluation
            popc(l).Objective = ObjectiveFunction(popc(l).Position);

            % Compare Solution to Best Solution Ever Found
            if popc(l).Objective < bestsol.Objective
                bestsol.Position = popc(l).Position;
                bestsol.Objective = popc(l).Objective;
            end

        end

        % Merge and Sort the populations
        pop = SortPopulation([pop; popc]);

        % Remove extra Individuals
        pop = pop(1:nPop);
        
        % Update Best Cost of Iteration
        bestcost(it) = bestsol.Objective;

        % Display Itertion Information
        disp(['Iteration ' num2str(it) ': Best Cost = ' num2str(bestcost(it))]);
        
    end
    
   % End timing for this run
    runtime_data(io) = toc;
    
 %BestCost for n number of runs
    optimalruns(io)=min(bestcost);
    
 %%% Exporting optimum values to excel %%%%
Algorithm = {'Genetic_Algorithm'};
Minvalt = min(bestcost); %%% Assigning the optimum value of each algorithm to minvalt
Comparison = table(Minvalt, 'VariableNames', {'Minvalt'}); %%% changing into a table form
filename = 'Genetic_Algorithm_Benchmarks_Optimal_Values.xlsx';   %%% Creating excel file

if io<27  %%% for the first 26 runs, this is to store the values in excel column cells A to z
    Letter=char('A'+ z);
    range=[Letter '2'];
    
else  %%% for runs 27 to 50, this is to store the values in excel column cells AA to AX
    Letter=char('A'+ z);
    range1 = ['A' Letter];
    range=[range1 '2'];
end

z=z+1;
if io==26
    z=0;
end

writetable(Comparison,filename,'Sheet', uu,'Range',range) %%%writing into the the excel file

end

% Calculate timing statistics for current function
    avg_runtime = mean(runtime_data);
    min_runtime = min(runtime_data);
    max_runtime = max(runtime_data);
    std_runtime = std(runtime_data);
       
    % Create timing statistics table
    timing_stats = table(...
        {Fun_name}, ...
        avg_runtime, ...
        min_runtime, ...
        max_runtime, ...
        std_runtime, ...
        sum(runtime_data), ...
 'VariableNames', {'Function', 'Average_Runtime', 'Min_Runtime', 'Max_Runtime', 'Std_Runtime', 'Total_Runtime'});
    
    % Write timing statistics to Excel
 writetable(timing_stats, timing_filename, 'Sheet', 'Summary', 'Range', ['A' num2str(uu+1)], 'WriteVariableNames', false );
    
    % Export individual run times to Excel
    run_numbers = (1:runs)';
    individual_runtimes = table(run_numbers, runtime_data, 'VariableNames', {'Run_Number', 'Runtime_Seconds'});
    writetable(individual_runtimes, timing_filename, 'Sheet', Fun_name, 'Range', 'A1');
       
% Calculate and display overall statistics
bestfitnessruns=min(optimalruns);
Mean=mean(optimalruns);
Standarddeviation= std(optimalruns);
bestfitnessruns
Mean
Standarddeviation

% %Exporting Convergence Curve values for each func (F1-F23) to excel sheet
filename1 = 'Genetic_Algorithm_Benchmarks_convergencecurves.xlsx';
Algorithm1 = {'Genetic_Algorithm'};
Genetic_conv = [bestcost'];
Comparison1=table( Genetic_conv);
writetable(Comparison1,filename1,'Sheet', uu,'Range','B2')

end
