clc;
close all
clearvars

z=0;
runs= 30;
optimalruns=zeros(runs,1);
runtime_data = zeros(runs,1);  % Array to store runtime for each run

% Create timing statistics Excel file with headers first
timing_filename = 'Blackhole_Algorithm_Benchmark_Timing_Statistics.xlsx';

% Create header row for summary sheet at the beginning
summary_header = table(...
    {'Function'}, ...
    {'Average_Runtime'}, ...
    {'Min_Runtime'}, ...
    {'Max_Runtime'}, ...
    {'Std_Runtime'}, ...
    {'Total_Runtime'}, ...
    'VariableNames', {'Function', 'Average_Runtime', 'Min_Runtime', 'Max_Runtime', 'Std_Runtime', 'Total_Runtime'});

writetable(summary_header, timing_filename, 'Sheet', 'Summary', 'Range', 'A1');

  
for uu=1:23   %loop for Engineering problems or benchmark functions i.e. max(uu)=10 for engineering problems
             %if you want to run only one benchmark say F6 for CEC benchmarks, the loop will
             %be "for uu=6:6"
    
   clear newstarCost distancebtnStarsandblackhole ...
      blackhole Stars ...
       bestIndices newPositionOfStars
    
%Reset z for each new benchmark function (F2,F3,...,Fn) run
if uu>1
    z=0;
end
    
Letter = char('F'); %Basically assigning letter F to 'Letter'   
range = [Letter num2str(uu)]; %forming the fun name i.e F1, F2, F3 etc, the loop for the functions determines th value of u
Fun_name = range; 

%%Use this code when testing Blackhole on the set of 23 standard CEC benchmarks
[lb,ub,D,out] = fun_info(Fun_name);
lowerbound = lb;
upperbound = ub;
dimension = D;
fitness = out;

% %%Use this code when testing Blackhole on the 10 Engineering benchmarks
% [lb,ub,D,out] = fun_eng(Fun_name);
% lowerbound = lb;
% upperbound = ub;
% dimension = D;
% fitness = out;

for io=1:runs
    % Start timing for this run
        tic;
        
ObjectiveFunction=fitness;
nVar=dimension;
varMin=lowerbound;
varMax=upperbound;

%Blackhole algorithm Parameters
    maxIter = 2000 ; % Total number of iterations
    nStar = 50;% Initial population size
    
    % Initialize the stars randomly with size nStar
    Stars = zeros(nStar, nVar);
    for i=1:nVar
        % Check if varMin and varMax are scalars; if so, create vectors with the same value
        if isscalar(varMin)
            varMin = varMin * ones(1, nVar);
        end
        if isscalar(varMax)
            varMax = varMax * ones(1, nVar);
        end
        
        % Check if varMin and varMax have the correct dimensions
        if numel(varMin) ~= nVar || numel(varMax) ~= nVar
            error('varMin and varMax should have nVar elements.');
        end
        Stars(:,i) = varMin(i)+rand(nStar,1).*(varMax(i) - varMin(i));  % Initial population
    end
    
    bestIndividual = zeros(maxIter,nVar);
    bestFitness = zeros(maxIter,1);
    maxCost=zeros(maxIter,1); 
        
 %Evaluate the fitness of each star in the population using the Obj Func
        starCost = zeros(nStar,1);
        
        %Main loop of the blackhole algorithm
        for iBH = 1:maxIter
            for a =1:nStar
                starCost(a) = ObjectiveFunction(Stars(a,:));
            end
            
            
            % Find the index of the star with the best fitness
            [~,bestIndex] = min(starCost);
            blackholeCost = min(starCost);
            
            %Select the star wih the best fitness as the blackhole
            blackhole = Stars(bestIndex,:) ;
            
            %Initialize variables
            newPositionOfStars = zeros(nStar,nVar);
            newstarCost = zeros(nStar,1); 
            
                for j = 1:nStar
                    
                    if j ~= bestIndex
                        %Calculate the new positions of Stars based on their current position
                        %and the blackhole position i.e. Xi(t+1)=Xi(t)+rand(0,1).*[Xbh - Xi(t)]
                        
                        % NOTE:KEEP Blackhole position constant until the stars move to a better
                        % position whose fitness is better than the fitness of the blackhole.
                        
                        newPositionOfStars(j,:) = Stars(j,:)+ unifrnd(0,1,[1 nVar]).*(blackhole - Stars(j,:)) ;
                         %Enforce bounds
                        newPositionOfStars = EnforceBounds(newPositionOfStars, varMin, varMax);
                         %Evaluate the new fitness of the newPositionOfStars
                        newstarCost(j,:) = ObjectiveFunction(newPositionOfStars(j,:)) ;
                    else
                        newPositionOfStars(j,:)=blackhole ;
                        %Evaluate the new fitness of the newPositionOfStars
                        newstarCost(j,:) = ObjectiveFunction(newPositionOfStars(j,:)) ;
                    end
                end
                
    % Find the index of the newPositionOfstars with the best fitness
            [~,newbestIndex] = min(newstarCost);
            newblackholeCost = min(newstarCost) ;
            
            %Select the star with the best fitness from the newPositionOfStars
            %as the newblackhole
            newblackhole = newPositionOfStars(newbestIndex,:);
             
            if newblackholeCost <= blackholeCost
                blackhole = newblackhole ;
                bestIndex = newbestIndex ;
                blackholeCost = newblackholeCost ;
            end
            
            Stars = newPositionOfStars ;
            starCost = newstarCost ;
            
            % Compute the Radius(R) of the Event Horizon/Boundary of the Black Hole
            R = blackholeCost / sum(starCost) ;
            blackholeRadius = R ;
            
            %Calculate distance between stars and blackhole
            distancebtnStarsandblackhole = zeros(nStar,1);
            for g = 1:nStar
                if g ~= bestIndex
                    distancebtnStarsandblackhole(g,:) = norm(blackhole - Stars(g,:)) ;
                else
                    distancebtnStarsandblackhole(g,:) = blackholeRadius  ;
                end
            end
            
            %Apply the event horizon/boundary of the blackhole
            % Identify stars within the event horizon
            insideEventHorizon = distancebtnStarsandblackhole < R ;
            
            %Remove stars inside the event horizon
            Stars(insideEventHorizon,:) = [] ;
            starCost(insideEventHorizon) = [] ;
            
            %Generate  new stars to replace the eliminated stars violating
            %the blackhole boundary or event horizon
            numOfeliminatedStars = sum(insideEventHorizon) ;
            
            %Criteria for Setting the evolution rate for generating new stars
            %after eliminating stars that cross the event horizon
            newStars = zeros(numOfeliminatedStars,nVar);
            
                for h=1:numOfeliminatedStars
                    individual = unifrnd(varMin,varMax,1,nVar);
                    newStars(h,:) = individual;
                end
          
            %Merge the newly generated stars with the remaining stars
            Stars = [Stars;newStars] ;
            
            %Enforce bounds
            Stars = EnforceBounds(Stars, varMin, varMax); 
                         
            % Store the best index and fitness for the current iteration
        bestIndices(iBH) = bestIndex;
        bestIndividual(iBH,:) = Stars(bestIndex,:);  
        bestFitness(iBH) = blackholeCost;

disp(['Iteration ' num2str(iBH) ': Best Cost = ' num2str(bestFitness(iBH)) ]);
        
        end
        
% End timing for this run
    runtime_data(io) = toc;
    
 %BestCost for n number of runs
    optimalruns(io)=min(bestFitness);
    
 %%% Exporting optimum values to excel %%%%
Algorithm = {'Blackhole_Algorithm'};
Minvalt = min(bestFitness); %%% Assigning the optimum value of each algorithm to minvalt
Comparison = table(Minvalt, 'VariableNames', {'Minvalt'}); %%% changing into a table form
filename = 'Blackhole_Algorithm_Benchmarks_Optimal_Values.xlsx';   %%% Creating excel file

if io<27  %%% for the first 26 runs, this is to store the values in excel column cells A to z
    Letter=char('A'+ z);
    range=[Letter '2'];
    
else  %%% for runs 27 to 50, this is to store the values in excel column cells AA to AX
    Letter=char('A'+ z);
    range1 = ['A' Letter];
    range=[range1 '2'];
end

z=z+1;
if io==26
    z=0;
end

writetable(Comparison,filename,'Sheet', uu,'Range',range) %%%writing into the the excel file

end

% Calculate timing statistics for current function
    avg_runtime = mean(runtime_data);
    min_runtime = min(runtime_data);
    max_runtime = max(runtime_data);
    std_runtime = std(runtime_data);
       
    % Create timing statistics table
    timing_stats = table(...
        {Fun_name}, ...
        avg_runtime, ...
        min_runtime, ...
        max_runtime, ...
        std_runtime, ...
        sum(runtime_data), ...
 'VariableNames', {'Function', 'Average_Runtime', 'Min_Runtime', 'Max_Runtime', 'Std_Runtime', 'Total_Runtime'});
    
    % Write timing statistics to Excel
 writetable(timing_stats, timing_filename, 'Sheet', 'Summary', 'Range', ['A' num2str(uu+1)], 'WriteVariableNames', false );
    
    % Export individual run times to Excel
    run_numbers = (1:runs)';
    individual_runtimes = table(run_numbers, runtime_data, 'VariableNames', {'Run_Number', 'Runtime_Seconds'});
    writetable(individual_runtimes, timing_filename, 'Sheet', Fun_name, 'Range', 'A1');
       
% Calculate and display overall statistics
bestfitnessruns=min(optimalruns);
Mean=mean(optimalruns);
Standarddeviation= std(optimalruns);
bestfitnessruns
Mean
Standarddeviation

% %Exporting Convergence Curve values for each func (F1-F23) to excel sheet
filename1 = 'Blackhole_Benchmarks_convergencecurves.xlsx';
Algorithm1 = {'Blackhole_Algorithm'};
Blackhole_conv = [bestFitness'];
Comparison1=table( Blackhole_conv);
writetable(Comparison1,filename1,'Sheet', uu,'Range','B2')

end
