function y = Mutation(x,mu,varMin,varMax)
nVar = numel(x);
nmu = ceil(mu*nVar);
j = randsample(nVar,nmu);
sigma(1:nVar) = (0.1*(varMax-varMin))/0.1;
y=x;
y(j) =x(j)+sigma(j)*(randn(size(j))');
y=max(y,varMin); y = min(y, varMax);
end
















% 
%Improved Gaussian Mutation
% function y = Mutation(x,mu,varMin,varMax)
% nVar = size(x(:,:),2);
% nmu = ceil(mu*nVar);
% j = randsample(nVar,nmu);
% n=size(x,1); 
% for i=1:n
% if i==1
% sigma = abs(x(1,:)-x(n,:))/6;
% else
% sigma = abs(x(i,:)-x(i-1,:))/6;
% end
% end
% y=x;
% for i=1:n
%     y(i,j)=x(i,j)+sigma(j)*(randn(size(j))');
% end
% 
% 
% y=max(y,varMin); y = min(y, varMax);
% end
% % mutatedoffspring = Mutation(sortedoffspring, mu, varMin,varMax) ;


%  function y = Mutation(x,mu,varMin,varMax)
% nVar = numel(x);
% nmu = ceil(mu*nVar);
% j = randsample(nVar,nmu);
% CM(1:nVar) = tan(pi*(unifrnd(0,1) - 0.5));
% y=x;
% y(j) =x(j)+CM(j)*(randn(size(j))');
% y=max(y,varMin); y = min(y, varMax);
% end