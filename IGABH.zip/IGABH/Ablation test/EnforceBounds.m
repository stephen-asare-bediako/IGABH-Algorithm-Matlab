function X = EnforceBounds(X, varMin, varMax)
    % Clip each variable to its bounds
    for i = 1:size(X, 2)
        X(:, i) = max(varMin(i), min(varMax(i), X(:, i)));
    end
end