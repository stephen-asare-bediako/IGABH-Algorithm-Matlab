%NOTE: Remember to change the file path "fis=readfis('C:\Users\user\Desktop\New folder\Adaptiveweight3.fis');"
%to the appropriate file path for your PC


%NEW FUZZY GABH
% Genetic Algorithm Parameters
clc;
close all
clearvars

z=0;
runs= 30;
optimalruns=zeros(runs,1);
runtime_data = zeros(runs,1);  % Array to store runtime for each run

% Create timing statistics Excel file with headers first
timing_filename = 'IGABH_Without_enhanced_Mayfly_Crossover_Timing_Statistics.xlsx';

% Create header row for summary sheet at the beginning
summary_header = table(...
    {'Function'}, ...
    {'Average_Runtime'}, ...
    {'Min_Runtime'}, ...
    {'Max_Runtime'}, ...
    {'Std_Runtime'}, ...
    {'Total_Runtime'}, ...
    'VariableNames', {'Function', 'Average_Runtime', 'Min_Runtime', 'Max_Runtime', 'Std_Runtime', 'Total_Runtime'});

writetable(summary_header, timing_filename, 'Sheet', 'Summary', 'Range', 'A1');

for uu=20:20   %loop for Engineering problems or benchmark functions i.e. NB: max(uu)= 10 for engineering
             %if you want to run only one benchmark say F6 for CEC benchmarks, the loop will
             %be "for uu=6:6"
    
    clear pop newpop elitePopulation newIndividuals blackhole ...
      newstarCost MergedPopulation offspringFitness Stars ...
      sortedMergedPopulation newPositionOfStars distancebtnStarsandblackhole
    
%Reset z for each new benchmark function (F2,F3,...,Fn) run
if uu>1
    z=0;
end
    
Letter = char('F'); %Basically assigning letter F to 'Letter'   
range = [Letter num2str(uu)]; %forming the fun name i.e F1, F2, F3 etc, the loop for the functions determines th value of u
Fun_name = range; 

%%Use this code when testing Hybrid_PEIGEO on the set of 23 standard CEC benchmarks
[lb,ub,D,out] = fun_info(Fun_name);
lowerbound = lb;
upperbound = ub;
dimension = D;
fitness = out;

for io=1:runs
    
% Start timing for this run
        tic;
        
ObjectiveFunction=fitness;
nVar=dimension;
varMin=lowerbound;
varMax=upperbound;
 
%IGABH algorithm parameters
 maxIt = 5;
 maxIter = 2000; % Total number of iterations
 nPop = 50;% Initial population size
 nStar = nPop;
 n0 = 40; %mean or avg pop size
 T = 10; % Period of variation or variable_pop_interval(i.e.for every 10 iterations)
 variable_pop_interval = T;
 D = 95; % Amplitude
 mu = 0.02; % Mutation rate
 pC = 1; % Crossover probability
 nC = round(pC * nPop / 2) * 2;
    
    % Initialize the population randomly with size nPop
    pop=zeros(nPop, nVar);
    for i=1:nVar
        % Check if varMin and varMax are scalars; if so, create vectors with the same value
        if isscalar(varMin)
            varMin = varMin * ones(1, nVar);
        end
        if isscalar(varMax)
            varMax = varMax * ones(1, nVar);
        end
        
        % Check if varMin and varMax have the correct dimensions
        if numel(varMin) ~= nVar || numel(varMax) ~= nVar
            error('varMin and varMax should have nVar elements.');
        end
        pop(:,i) = varMin(i)+rand(nPop,1).*(varMax(i) - varMin(i));                          % Initial population
    end
    
    bestIndividual = zeros(maxIter,nVar);
    bestFitness = inf;
    maxCost = zeros(maxIter,1); 
    evolution_rate_values = zeros(maxIter,1);
    bestIndices=zeros(maxIter,1);
    x1=0;
    x2=0;
    CBPE_min=-3.32237; %Set the true global optimum value of the benchmark func
    evolution_rate=0.2;
    
    % Main loop
    for iter = 1:maxIter
        %Check if its time for population reinitialization
        if mod(iter,variable_pop_interval)==0
            % Elitism: Keep the best individual from the previous generation
            %Retain 10 individuals with the best fitness values
            Fitness1 = zeros(nPop,1);
            for q= 1:nPop
                Fitness1(q)= ObjectiveFunction(pop(q,:));
            end
            [~,sortedIndices] = sort(Fitness1);
            elitePopulation = pop(sortedIndices(1:10),:);
            
            %Replace the remaining (nPop-10) individuals randomly
            newIndividuals = zeros(nPop-10,nVar);
            for i=1:nVar
                newIndividuals(:,i) = varMin(i)+rand(nPop-10,1).*(varMax(i) - varMin(i));     % Initial population
            end
            pop = [elitePopulation;  newIndividuals];
        else
            pop=pop;
        end
        % Evaluate fitness of the individuals in the population
        fitnessValues = zeros(nPop,1);
        for j= 1:nPop
            fitnessValues(j) = ObjectiveFunction(pop(j,:));
        end
        % Tournament Selection
        nSelected = nPop; % Number of selected individuals
        selectedIndices = zeros(1, nSelected);
        for i = 1:nSelected
            tournamentSize = 5; % Adjust as needed
            tournamentIndices = randperm(nPop, tournamentSize) ;
            [~, idx] = min(fitnessValues(tournamentIndices));
            selectedIndices(i) = tournamentIndices(idx);
        end
        
        selectedPopulation = pop(selectedIndices, :) ;
        
        % Apply Uniform Crossover to produce offspring
        offspring1=zeros(nC/2,nVar);
        offspring2=zeros(nC/2,nVar);
        for k = 1:nC/2
            parentpopmatrix = selectedPopulation;
            %Number of parents to be selected from parentpopmatrix
            parentstoSelect = 2;
            parents_indices = randperm(size(parentpopmatrix,1),parentstoSelect) ;
            parents = parentpopmatrix(parents_indices,:) ;  %Parents selection
            [offspring1(k,:), offspring2(k,:)] = UniformCrossover(parents(1,:),parents(2,:)) ;
        end
        
        offspring = [offspring1;offspring2] ;
        offspring = EnforceBounds(offspring, varMin, varMax);
        
        for m=1:size(offspring,1)
            offspringFitness(m) = ObjectiveFunction(offspring(m,:)) ;
        end
        
        [sortedfitness, sortedIndices1] = sort(offspringFitness) ;
        sortedoffspring = offspring(sortedIndices1(1:m),:) ;
        
        % Apply Mutation to the offspring
        mutatedoffspring = zeros(size(sortedoffspring,1),nVar);
        for n=1:nC
            mutatedoffspring(n,:) = Mutation(sortedoffspring(n,:), mu, varMin,varMax);
        end
        
         %Enforce Upper & lower bounds
        mutatedoffspring = EnforceBounds(mutatedoffspring, varMin, varMax);
        
        %Merge the population and mutated offspring
        newpop= [pop;mutatedoffspring] ;
        
        % Evaluate the fitness of the new population and sort
        newpopFitness = zeros(size(newpop,1),1);
        for f=1:size(newpop,1)
            newpopFitness(f) = ObjectiveFunction(newpop(f,:)) ;
        end
        [sortedFitness1, sortedIndices2] = sort(newpopFitness) ;
        sortednewpop = newpop(sortedIndices2, :) ;
        
        % Remove extra individuals
        %sortednewpop = sortednewpop(1:nPop, :) ;
        
        % Update the population size (variable population size)
        if mod(iter,variable_pop_interval)== 0
            %Find new pop size
            NewnPop =abs(round(n0 + D - (2 * D / T - 1) * max(0, (iter - (T * floor((iter - 1) / T) + 1)))));
            %popofNewPopsize = rand(NewnPop,nVar) ;
           popofNewPopsize = zeros(NewnPop,nVar);
      for ii=1:nVar
      % Check if varMin and varMax are scalars; if so, create vectors with the same value
         if isscalar(varMin)
            varMin = varMin * ones(1, nVar);
         end
         if isscalar(varMax)
             varMax = varMax * ones(1, nVar);
         end
                  
         popofNewPopsize(:,ii) = varMin(ii)+rand(NewnPop,1).*(varMax(ii) - varMin(ii));                          % Initial population
     end
            popofNewnPop = popofNewPopsize ;
            
            %Merge  sortednewpop and popofNewnPop
            MergedPopulation = [sortednewpop;popofNewnPop];
        else
            MergedPopulation = sortednewpop;    
        end
        
        %Enforce bounds
        MergedPopulation = EnforceBounds( MergedPopulation, varMin, varMax);
        
        MergedPopulationFitness=zeros(1,size(MergedPopulation,1));
        for g=1:size(MergedPopulation,1)
            MergedPopulationFitness(g) = ObjectiveFunction(MergedPopulation(g,:)) ;
        end
        
        [sortedFitness2, sortedIndices3] = sort(MergedPopulationFitness) ;
        
        sortedMergedPopulation = zeros(size(MergedPopulation,1), nVar);
        
        for e = 1:size(MergedPopulation,1)
            sortedMergedPopulation(e,:) = MergedPopulation(sortedIndices3(e),:) ;
        end
        
        % Remove extra individuals
        sortedMergedPopulation = sortedMergedPopulation(1:nPop, :) ;
        
         %Enforce bounds
        sortedMergedPopulation = EnforceBounds(sortedMergedPopulation, varMin, varMax);
        
        % Update the population
        finalpop =  sortedMergedPopulation ;
        
        %Initialize stars/candidate solutions randomly in the search space
        %(population initialization)
        Stars = finalpop ;
        
        %Evaluate the fitness of each star in the population using the Obj Func
        starCost = zeros(nStar,1);
        
        %Main loop of the blackhole algorithm
        for iBH = 1:maxIt
            for a =1:nStar
                starCost(a) = ObjectiveFunction(Stars(a,:));
            end
            
            % Find the index of the star with the best fitness
            [~,bestIndex] = min(starCost);
            blackholeCost = min(starCost);
            
            %Select the star wih the best fitness as the blackhole
            blackhole = Stars(bestIndex,:) ;
            
            runs_Q=3;
            for i=1:runs_Q
                
                for j = 1:nStar
                    
                    if j ~= bestIndex
                        %Calculate the new positions of Stars based on their current position
                        %and the blackhole position i.e. Xi(t+1)=Xi(t)+rand(0,1).*[Xbh - Xi(t)]
                        
                        % NOTE:KEEP Blackhole position constant until the stars move to a better
                        % position whose fitness is better than the fitness of the blackhole.
                        
                        newPositionOfStars(j,:) = Stars(j,:)+unifrnd(0,1,[1 nVar]).*(blackhole - Stars(j,:)) ;
                        %Enforce bounds
                        newPositionOfStars = EnforceBounds(newPositionOfStars, varMin, varMax);
                        newstarCost(j,:) = ObjectiveFunction(newPositionOfStars(j,:)) ;
                    else
                        newPositionOfStars(j,:)=blackhole ;
                        %Evaluate the new fitness of the newPositionOfStars
                        newstarCost(j,:) = ObjectiveFunction(newPositionOfStars(j,:)) ;
                    end
                end
                
                
            end
            % Find the index of the newPositionOfstars with the best fitness
            [~,newbestIndex] = min(newstarCost);
            newblackholeCost = min(newstarCost) ;
            %Select the star with the best fitness from the newPositionOfStars
            %as the newblackhole
            newblackhole = newPositionOfStars(newbestIndex,:);
            
            if newblackholeCost <= blackholeCost
                blackhole = newblackhole ;
                bestIndex = newbestIndex ;
                blackholeCost = newblackholeCost ;    
            end
            
            Stars = newPositionOfStars ;
            starCost = newstarCost ;
            
            % Compute the Radius(R) of the Event Horizon/Boundary of the Black Hole
            R = blackholeCost / sum(starCost) ;
            blackholeRadius = R ;
            
            %Calculate distance between stars and blackhole
            for g = 1:nStar
                if g ~= bestIndex
                    distancebtnStarsandblackhole(g,:) = norm(blackhole - Stars(g,:)) ;
                else
                    distancebtnStarsandblackhole(g,:) = blackholeRadius  ;
                end
            end
            
            %Apply the event horizon/boundary of the blackhole
            % Identify stars within the event horizon
            insideEventHorizon = distancebtnStarsandblackhole < R ;
            
            %Remove stars inside the event horizon
            Stars(insideEventHorizon,:) = [] ;
            starCost(insideEventHorizon) = [] ;
            
            %Generate  new stars to replace the eliminated stars violating
            %the blackhole boundary or event horizon
            numOfeliminatedStars = sum(insideEventHorizon) ;
            
            %Criteria for Setting the evolution rate for generating new stars
            %after eliminating stars that cross the event horizon
            newStars = zeros(numOfeliminatedStars,nVar);
            a = nStar - numOfeliminatedStars;
            spaceX=1;
            evolution_rate1 = 1-evolution_rate;
            if a<2
                for h=1:numOfeliminatedStars
                    individual = unifrnd(varMin,varMax,1,nVar);
                    newStars(h,:) = individual;
                end
            else
                while a>=2 && spaceX<=numOfeliminatedStars
                    spaceX=spaceX+1;
                    if evolution_rate>=evolution_rate1 && mod(iter,100)~=0
                        for h=1:numOfeliminatedStars
                            if randn()<=evolution_rate
                                new_individual = unifrnd(varMin,varMax,1,nVar);
                                newStars(h,:) = new_individual;
                            end
                        end
                        
                    elseif evolution_rate<evolution_rate1 || mod(iter,100)==0
                        for h=1:numOfeliminatedStars
                            individual_solutions = unifrnd(varMin,varMax,1,nVar);
                            newStars(h,:) = individual_solutions;
                        end
                    end
                end
            end
            
            %Merge the newly generated stars with the remaining stars
            Stars = [Stars;newStars] ;
            
            %Enforce bounds
            Stars = EnforceBounds(Stars, varMin, varMax);
            
            %Assign the Stars matrix to pop and continue the combined algorithm loop
            %pop =zeros(nStar,nVar) ;
            pop =Stars ;
                        
            % Store the best index and fitness for the current iteration
            bestIndices(iter) = bestIndex;
            bestFitness(iter) = blackholeCost;
            
        end

Alpha_fitness = zeros(nPop,1);
% Find the index of the individual in pop with the worst or max fitness
             for alpha =1:nPop
    Alpha_fitness(alpha) = ObjectiveFunction(pop(alpha,:));
             end
    [~,maxIndex] = max(Alpha_fitness);
    WorstCost = max(Alpha_fitness);
 %Select the individual wih the best fitness as the blackhole
    worstIndividual = pop(maxIndex,:) ;
    maxCost(iter) = WorstCost;
        
     evolution_rate_values(1)= 0.2;
                
        if iter>=1
            CBPE= bestFitness(iter);
            CBPE_max = maxCost(iter);
            NCBPE=(CBPE-CBPE_min)/(CBPE_max-CBPE_min);
            x1=NCBPE;
            x2=evolution_rate;
            assignin('base','x1',x1);
            assignin('base','x2',x2);
            fis=readfis('C:\Users\user\Desktop\New folder\Adaptivealpha.fis');
  %         fis=readfis('C:\Users\lya223\Downloads\Steve_GenAlgorithm_Friday\Steve_GenAlgorithm\New folder (2)\New folder (2)\Adaptiveweight3.fis');
            x1 = max(0, min(1, x1));   % clamp NCBPE to avoid classic floating-point drift caused by accumulated numeric operations
            x2 = max(0, min(1, x2));   % clamp evolution_rate classic floating-point drift caused by accumulated numeric operations
            change_in_evolution_rate = evalfis([x1,x2],fis);
            finalVal = change_in_evolution_rate;
            evolution_rate =  finalVal;
            evolution_rate_values(iter+1)= evolution_rate;
        end
       
        bestIndices(iter) = bestIndex;
        bestIndividual(iter,:) = pop(bestIndex,:);  
        bestFitness(iter) = blackholeCost;

disp(['Iteration ' num2str(iter) ': Best Cost = ' num2str(bestFitness(iter))  ': MaximumCost = ' num2str(maxCost(iter))]);
        
   end
    
 % End timing for this run
    runtime_data(io) = toc;
    
 %BestCost for n number of runs
    optimalruns(io)=min(bestFitness);
    
 %%% Exporting optimum values to excel %%%%
Algorithm = {'IGABH_Without_enhanced_Mayfly_Crossover'};
Minvalt = min(bestFitness); %%% Assigning the optimum value of each algorithm to minvalt
Comparison = table(Minvalt, 'VariableNames', {'Minvalt'}); %%% changing into a table form
filename = 'IGABH_Without_enhanced_Mayfly_Crossover_Optimal_Values.xlsx';   %%% Creating excel file

if io<27  %%% for the first 26 runs, this is to store the values in excel column cells A to z
    Letter=char('A'+ z);
    range=[Letter '2'];
    
else  %%% for runs 27 to 50, this is to store the values in excel column cells AA to AX
    Letter=char('A'+ z);
    range1 = ['A' Letter];
    range=[range1 '2'];
end

z=z+1;
if io==26
    z=0;
end

writetable(Comparison,filename,'Sheet', uu,'Range',range) %%%writing into the the excel file

end

% Calculate timing statistics for current function
    avg_runtime = mean(runtime_data);
    min_runtime = min(runtime_data);
    max_runtime = max(runtime_data);
    std_runtime = std(runtime_data);
       
    % Create timing statistics table
    timing_stats = table(...
        {Fun_name}, ...
        avg_runtime, ...
        min_runtime, ...
        max_runtime, ...
        std_runtime, ...
        sum(runtime_data), ...
 'VariableNames', {'Function', 'Average_Runtime', 'Min_Runtime', 'Max_Runtime', 'Std_Runtime', 'Total_Runtime'});
    
    % Write timing statistics to Excel
 writetable(timing_stats, timing_filename, 'Sheet', 'Summary', 'Range', ['A' num2str(uu+1)], 'WriteVariableNames', false );
    
    % Export individual run times to Excel
    run_numbers = (1:runs)';
    individual_runtimes = table(run_numbers, runtime_data, 'VariableNames', {'Run_Number', 'Runtime_Seconds'});
    writetable(individual_runtimes, timing_filename, 'Sheet', Fun_name, 'Range', 'A1');
       
% Calculate and display overall statistics
bestfitnessruns=min(optimalruns);
Mean=mean(optimalruns);
Standarddeviation= std(optimalruns);
bestfitnessruns
Mean
Standarddeviation

% %Exporting Convergence Curve values for each func (F1-F23) to excel sheet
filename1 = 'IGABH_Without_enhanced_Mayfly_Crossover_convergencecurves.xlsx';
Algorithm1 = {'IGABH_Without_enhanced_Mayfly_Crossover'};
IGABH_conv = [bestFitness'];
Comparison1=table( IGABH_conv);
writetable(Comparison1,filename1,'Sheet', uu,'Range','B2')

end

