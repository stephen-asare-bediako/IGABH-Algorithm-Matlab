% Crossover funcion definition
    function [off1, off2] = Crossover(x1,x2,varMin,varMax)
im1=rand();
im2=rand();
im3=rand();
pm1=0.8;
pm2=0.5;
pm3=0.5;
cm1=unifrnd(-1,1,size(x1));
cm2=unifrnd(-1,1,size(x1));
dm1=unifrnd(0.7,1,size(x1));
dm2=unifrnd(1,1.3,size(x1));
dm3=unifrnd(0.7,1,size(x1));
dm4=unifrnd(1,1.3,size(x1));
L=unifrnd(0,1,size(x1));
if im1<pm1
off1=L.*x1+(1-L).*x2;
elseif im1>pm1 && im2<pm2
 off1=L.*x1+(1-L).*x2+cm1.*(x1-x2);
elseif im1>pm1 && im2<pm2 && im3<pm3
 off1=dm1*L.*x1+(1-L).*x2;
elseif im1>pm1 && im2<pm2 && im3>pm3
    off1=dm3*L.*x1+(1-L).*x2;
else
    off1=L.*x1+(1-L).*x2;
end
if im1<pm1
off2=L.*x2+(1-L).*x1;
elseif im1>pm1 && im2<pm2
 off2=L.*x2+(1-L).*x1+cm2.*(x2-x1);
elseif im1>pm1 && im2<pm2 && im3<pm3
 off2=dm2*L.*x2+(1-L).*x1;
elseif im1>pm1 && im2<pm2 && im3>pm3
    off2=dm4*L.*x2+(1-L).*x1;
else
    off2=L.*x2+(1-L).*x1;
end
% Position Limits
off1=max(off1,varMin); off1=min(off1,varMax);
off2=max(off2,varMin); off2=min(off2,varMax);
end

