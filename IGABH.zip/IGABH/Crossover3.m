function [off1, off2]=Crossover3(x1,x2,LowerBound,UpperBound)
L=unifrnd(0,1,size(x1));
off1=L.*x1+(1-L).*x2;
off2=L.*x2+(1-L).*x1;
% Position Limits
off1=max(off1,LowerBound); off1=min(off1,UpperBound);
off2=max(off2,LowerBound); off2=min(off2,UpperBound);
end