function pop = SortPopulation(pop)

    [~, so] = sort([pop.Objective]);
    pop = pop(so);
    
end